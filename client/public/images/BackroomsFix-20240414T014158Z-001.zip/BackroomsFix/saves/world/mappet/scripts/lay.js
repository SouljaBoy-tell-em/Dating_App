function main(c)
{
    // Code...
    var s = c.getSubject();
    var morph = null;
    
    if (c.getValue("down"))
    {
        morph = mappet.createMorph("{Pose:\"lying\",Skin:\"" + s.getSkin() + "\",Settings:{Hands:1b,Speed:0.05},Name:\"blockbuster.fred\"}");
    }
    
    s.setMorph(morph);
}