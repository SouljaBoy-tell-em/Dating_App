function main(c)
{
        
            var ui = mappet.createUI(c, "passwordtest").background().closable(false);
            var textbox = ui.textbox().id("passwordstring").tooltip("Строка для пароля");
            var label = ui.label("[fВведите [eпароль[f:").id('labelpassword');
            c.executeCommand("/mp state set @a[team=surv] on_off 1")
            var buttonok = ui.button("Войти").id("buttonok");
            var buttonclose = ui.button("Выход").id("buttonclose");
            
            label.rxy(0.47,0.44).wh(100, 20).anchor(0.5);
            label.color(0x00ee22).background(0x88000000).labelAnchor(0.5);
            textbox.rxy(0.5, 0.5).wh(124, 20).anchor(0.5);
            buttonok.rxy(0.45, 0.57).wh(60, 20).anchor(0.5);
            buttonclose.rxy(0.57, 0.57).wh(40, 20).anchor(0.5);
            c.getSubject().openUI(ui);
}

        
        function passwordtest(c)
        {
            var states = c.getServer().getStates();
            var uiContext = c.getSubject().getUIContext();
            var data = uiContext.getData();
            var player = c.getSubject();
            var pos = c.getSubject().getPosition();
            var zero = 0;
            var s = c.getSubject();
        
            if (uiContext.getLast() === "passwordstring")
                {
                    c.getWorld().playSound("minecraft:entity.pig.ambient", pos.x, pos.y, pos.z, 0.5, 2);
                    s.swingArm()
                }
                
                    if (uiContext.getLast() === "buttonok")
                        {
                            var data = uiContext.getData();
                            var passtates = c.getServer().getStates();
                            s.swingArm()
                            
                            if (data.getString("passwordstring") == passtates.getNumber("password"))
                            {
                                s.setGameMode(3);
                                c.executeCommand("/tp @s -846 245 43 -45 20");
                                c.executeCommand("/voicemute mute "+player.getName()+"")
                                c.getSubject().closeUI();
                                s.swingArm()
                                c.scheduleScript('camera', 3);
                            }
                            if (data.getString("passwordstring") == passtates.getNumber("1979"))
                            {
                                s.setGameMode(2);
                                c.player.closeUI();
                                c.executeCommand("/playsound nz:death master @s[team=surv]");
                                c.scheduleScript('1979', 'main', 3);
                                c.executeCommand("/mp state set @a[team=surv] on_off 0");
                                s.swingArm()
                            }
                            else
                            {
                                 var label = uiContext.get('labelpassword');
                                 label.label('[4Неверный [fпароль');   
                                 s.swingArm()
                            }
                        }
                    if (uiContext.getLast() === "buttonclose")
                        {
                            c.getSubject().closeUI();
                            c.executeCommand("/voicemute unmute "+player.getName()+"")
                            c.executeCommand("/effect +c.player.name+ clear")
                            c.executeCommand("/mp state set @a[team=surv] on_off 0");
                            s.swingArm()
                        }
        }



function camera(c)
    {
    var states = c.getServer().getStates();
    var ui = mappet.createUI(c, 'cameraui').closable(false);
    var buttonclose = ui.button("Выход").id("buttonclose");
    var buttongo = ui.button("След.>>>").id("buttongo");
    var buttonback = ui.button("<<<Пред.").id("buttonback");
    var labelinfo1 = ui.label("Камера: 01 | Этаж 02 | Левое крыло").id('labelinfo').visible(true);
    var buttonsafe = ui.button("Открыть сейф").id("buttonsafe");
    if (states.getNumber("drist") == 0)
        {
            var labelsafe = ui.label("[fДистан. управление: [4откл ").id("labelsafe");
        }
    else if (states.getNumber("drist") == 1)
        {
            var labelsafe = ui.label("[fДистан. управление: [aвкл ").id("labelsafe");
        }
    else if (states.getNumber("drist") == 2)
        {
            var labelsafe = ui.label("[fСейф [aоткрыт. ").id("labelsafe");
        }
             
            
    labelsafe.rxy(0.9,0.85).wh(100, 20).anchor(0.5);
    labelsafe.background(0x88000000).labelAnchor(0.5);
    labelinfo1.rxy(0.5, 0.85).wh(100, 20).anchor(0.5);
    labelinfo1.background(0x88000000).labelAnchor(0.5);
    buttonsafe.rxy(0.9, 0.9).wh(80, 20).anchor(0.5);
    buttonclose.rxy(0.5, 0.9).wh(80, 20).anchor(0.5);
    buttongo.rxy(0.62, 0.9).wh(50, 20).anchor(0.5);
    buttonback.rxy(0.38, 0.9).wh(50, 20).anchor(0.5);
    c.executeCommand("/mp hud setup @s camera")
    
    c.getSubject().openUI(ui);
    }
    
var campos = 1
function cameraui(c)
    {
        var labelsafe = null
        var uiContext = c.getSubject().getUIContext();
        var states = c.getServer().getStates();
        var player = c.getSubject();
       
         if (uiContext.getLast() === "buttonclose")
            {
                c.getSubject().setGameMode(2);
                c.executeCommand("/tp @s -846 243 57 -159 17");
                c.executeCommand("/mp hud close @s");
                c.executeCommand("/voicemute unmute "+player.getName()+"")
                c.executeCommand("/mp state set @a[team=surv] on_off 0");
                c.getSubject().closeUI();
                campos = 1
            }
        if (uiContext.getLast() === "buttonsafe")
            {
                 if (states.getNumber("drist") == 0)
                     {
                         labelsafe = uiContext.get("labelsafe")
                         labelsafe.label("[fВключите [eДистан. управление. ").id("labelsafe");   
                     }
                 else if (states.getNumber("drist") == 1)
                     {
                         
                         labelsafe = uiContext.get("labelsafe")
                         labelsafe.label("[fСейф [aоткрыт. ").id("labelsafe");
                         states.setNumber("drist", 2);  
                         if (states.getNumber("safe_pos") == 0)
                             {
                                 c.executeCommand("/setblock -857 245 51 backrooms:safeunlock 5");
                             }
                         else if (states.getNumber("safe_pos") == 1)
                             {
                                 c.executeCommand("/setblock -820 232 67 backrooms:safeunlock");
                             }                       
                     } 
                 else if (states.getNumber("drist") == 100)
                     {
                         labelsafe = uiContext.get("labelsafe")
                         labelsafe.label("[fВключено [4Слепой...").id("labelsafe");   
                     }    
            }
        else if (uiContext.getLast() === "buttongo")
            {
                campos++
                 if (campos <= 0)
                    {
                        campos = 9
                    }
                    if (campos >= 10)
                    {
                        campos = 1
                    }
                    if (campos == 1)
                    {
                         c.executeCommand("/tp @s -846 245 43 -45 20");
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 00 | Этаж 02 | Коридор у лестницы');   
                    }
                    if (campos == 2)
                    {
                         c.executeCommand('/tp @s -831 245 51 40 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 01 | Этаж 02 | Главный коридор');   
                    }
                    if (campos == 3)
                    {
                        c.executeCommand('/tp @s -852.7 245.2 66.2 -128 26');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 02 | Этаж 02 | Правое крыло');
                    }
                    if (campos == 4)
                    {
                         c.executeCommand('/tp @s -849 239 56 -60 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 03 | Этаж 01 | Средний коридор');   
                    }
                    if (campos == 5)
                    {
                        c.executeCommand('/tp @s -821.300 238 39.300 40 10');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 04 | Этаж 00 | Южный коридор');   
                    }
                    if (campos == 6)
                    {
                         c.executeCommand('/tp @s -856 239 74 -120 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 05 | Этаж 00 | Северный коридор');   
                    }
                    if (campos == 7)
                    {
                         c.executeCommand('/tp @s -861.018 234.20000 59.300 -50 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 06 | Этаж 00 | Восточная лестница');
                    }
                    if (campos == 8)
                    {
                         c.executeCommand('/tp @s -835.290 234.2 43.987 -40 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 07 | Этаж 00 | Западное крыло');
                    }
                    if (campos == 9)
                    {
                         c.executeCommand('/tp @s -833.300 233.83130 67.520 140 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 08 | Этаж 00 | Главный коридор');
                    }
            }      
        else if (uiContext.getLast() === "buttonback")
            {
                campos--
                 if (campos <= 0)
                    {
                        campos = 9
                    }
                    if (campos >= 10)
                    {
                        campos = 1
                    }
                    if (campos == 1)
                    {
                         c.executeCommand("/tp @s -846 245 43 -45 20");
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 00 | Этаж 02 | Коридор у лестницы');   
                    }
                    if (campos == 2)
                    {
                         c.executeCommand('/tp @s -831 245 51 40 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 01 | Этаж 02 | Главный коридор');   
                    }
                    if (campos == 3)
                    {
                        c.executeCommand('/tp @s -852.7 245.2 66.2 -128 26');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 02 | Этаж 02 | Правое крыло');
                    }
                    if (campos == 4)
                    {
                         c.executeCommand('/tp @s -849 239 56 -60 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 03 | Этаж 01 | Средний коридор');   
                    }
                    if (campos == 5)
                    {
                        c.executeCommand('/tp @s -821.300 238 39.300 40 10');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 04 | Этаж 00 | Южный коридор');   
                    }
                    if (campos == 6)
                    {
                         c.executeCommand('/tp @s -856 239 74 -120 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 05 | Этаж 00 | Северный коридор');   
                    }
                    if (campos == 7)
                    {
                         c.executeCommand('/tp @s -861.018 234.20000 59.300 -50 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 06 | Этаж 00 | Восточная лестница');
                    }
                    if (campos == 8)
                    {
                         c.executeCommand('/tp @s -835.290 234.2 43.987 -40 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 07 | Этаж 00 | Западное крыло');
                    }
                    if (campos == 9)
                    {
                         c.executeCommand('/tp @s -833.300 233.83130 67.520 140 20');
                         var labelinfo1 = uiContext.get('labelinfo');
                         labelinfo1.label('Камера: 08 | Этаж 00 | Главный коридор');
                      }
                }
        }