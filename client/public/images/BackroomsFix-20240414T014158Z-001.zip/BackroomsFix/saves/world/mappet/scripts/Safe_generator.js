function main(c)
{
    var s = c.getSubject();
    var states = c.getServer().getStates();
    var rand = Math.random();
    rand = Math.round(rand);
    if (rand == 0)
        {
            states.setNumber("safe_pos", rand)
            c.executeCommand("/setblock -857 245 51 backrooms:safeclosed 5");
            c.executeCommand("/setblock -820 232 67 air");
        } 
    else if (rand == 1)
        {
            states.setNumber("safe_pos", rand)
            c.executeCommand("/setblock -820 232 67 backrooms:safeclosed");
            c.executeCommand("/setblock -857 245 51 air");
        }
}