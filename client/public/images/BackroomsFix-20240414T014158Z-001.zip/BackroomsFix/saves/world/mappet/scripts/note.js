function main(c)
{
    var ui = mappet.createUI(c, 'handler').closable(false); 
    var scroll = ui.column(5, 10)
    var button =ui.button("Закрыть").id("button");
    button.rxy(0.481, 0.77).wh(191, 15).anchor(0.4);
    
    scroll.getCurrent().scroll().rxy(0.5, 0.53).w(200).rh(0.8).anchor(0.5);                         

    var text = scroll.text("Мария Ален." +
        " Ваш сын не пришёл сегодня в школу." +
        " Я жду объяснительную записку от лица мальчика завтра." +
        " Если он не придёт и завтра." +
        " Вы должны будете отчитываться перед директором, за то, что не следите за тем как он ходит в школу." + 
        " Вы ведь знаете, то что у него проблемы с оценками." +
        "                                                            Подпись: Учитель математики, Томас Корсон");

      c.getSubject().openUI(ui);
}

 function handler(c)
{
  var uiContext = c.getSubject().getUIContext();
  var last = uiContext.last;
  var s = c.getSubject();

    if (uiContext.getLast() === "button")
    {
        c.executeCommand("/mp hud close @s note3")
         c.getSubject().closeUI();
}

}