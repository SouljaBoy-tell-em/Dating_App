function main(c)
{
    // Code...
    var s = c.getSubject();
    var morph = null;
    
    if (c.getValue("down"))
    {
        morph = mappet.createMorph("{Pose:\"normal\",Skin:\"" + s.getSkin());
    }
    
    s.setMorph(morph);
}