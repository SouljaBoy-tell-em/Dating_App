function main(c)
{
    var ui = mappet.createUI(c, 'handler').background().closable(false);
    var graphics = ui.graphics().rx(0.65, -226).ry(0.72, -199).wh(200, 250);
    var buttonok = ui.button("\u00A74%fgp@feq4j%").id("buttonok");
    var label = ui.label("Вся правда на стенах.").id("label");
    
    buttonok.rxy(0.5, 0.6).wh(160, 20).anchor(0.5);
    label.rxy(0.5, 0.54).wh(120, 90).anchor(0.5);
    label.background(0xffff0000);
    label.color(0x00000000);
    
    graphics.rect(1, 0, 162, 148, 0x88000000);
     
     c.getSubject().openUI(ui);
}

function handler(c){
     var uiContext = c.getSubject().getUIContext();
    
    if (uiContext.getLast() === "buttonok")
    {    
    c.getSubject().closeUI();
    c.executeCommand("/tp @s[team=surv] -848 237 21 -89.5 1.1");
    c.executeCommand("/mp event trigger @s[team=surv] 1979");
    s.swingArm()
    }
}