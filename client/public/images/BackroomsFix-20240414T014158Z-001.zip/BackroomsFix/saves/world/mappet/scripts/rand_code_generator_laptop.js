function main(c) 
{
    var states = c.getServer().getStates();
    var s = c.getSubject();
    var pas = (Math.random() * 9999);
    pas = Math.round(pas);
    
    if (pas <= 999)
        {
            pas = pas + 1000;
        }
    states.setNumber("password", pas);
    c.scheduleScript("generator",1);
    c.executeCommand("/modelblock morph -838 240 76");
    c.executeCommand("/modelblock morph -850 246 69");
    c.executeCommand("/modelblock morph -827 240 61");
    c.executeCommand("/modelblock morph -816 246 71");
}

function generator(c)
{
    var gay  = c.getServer().getStates().getNumber("password");
    var states = c.getServer().getStates();
    var rand = (Math.random() * 3);
    rand = Math.round(rand);
    if (rand == 0)
    {
        c.executeCommand("/modelblock morph -838 240 76 {Lighting:0b,DisplayName:\"2code\",Label:\"" + states.getNumber("password") + "\",Settings:{Hands:1b},Name:\"label\"}")
    }
    else if (rand == 1)
    {
        c.executeCommand("/modelblock morph -850 246 69 {Lighting:0b,DisplayName:\"2code\",Label:\"" + states.getNumber("password") + "\",Settings:{Hands:1b},Name:\"label\"}")
    }
    else if (rand == 2)
    {
         c.executeCommand("/modelblock morph -827 240 61 {Lighting:0b,DisplayName:\"2code\",Label:\"" + states.getNumber("password") + "\",Settings:{Hands:1b},Name:\"label\"}")   
    }
    else if (rand == 3)
    {
        c.executeCommand("/modelblock morph -816 246 71 {Lighting:0b,DisplayName:\"2code\",Label:\"" + states.getNumber("password") + "\",Settings:{Hands:1b},Name:\"label\"}")
    }
    
    
    
    
}