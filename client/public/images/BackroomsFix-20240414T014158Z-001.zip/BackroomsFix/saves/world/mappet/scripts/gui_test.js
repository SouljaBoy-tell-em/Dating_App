function main(c)
{
    var ui = mappet.createUI(c, 'handler').closable(false);
    var s = c.getSubject();
    var button =ui.button("Закрыть").id("button");
    button.rxy(0.481, 0.95).wh(191, 15).anchor(0.4);


    c.executeCommand("/mp hud setup @s Jorge_Alen_List")

     c.getSubject().openUI(ui);
}
 function handler(c)
{
  var uiContext = c.getSubject().getUIContext();
  var last = uiContext.last;
  var s = c.getSubject();

    if (uiContext.getLast() === "button")
    {
        c.executeCommand("/mp hud close @s Jorge_Alen_List")
         c.getSubject().closeUI();
}

}