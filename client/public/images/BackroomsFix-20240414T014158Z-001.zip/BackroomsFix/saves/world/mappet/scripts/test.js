function main(c) 
{
    var ui = mappet.createUI(c, 'passwordtest').background();
    var textbox = ui.textbox().id('textbox').tooltip('Пароль от WI-FI');
    var ui = mappet.createUI(c, "passwordtest").background();
    var textbox = ui.textbox().id("passwordstring").tooltip("Выполните выражение:");
    var label = ui.label("Выполните выражение: \u00A7a 13 + 70").id('labelpassword');
    var buttonok = ui.button("Принять").id("buttonok");
    var buttonok2 = ui.button("Отключить свет").id("buttonok2");
    var buttonok3 = ui.button("Включить свет").id("buttonok3");

    label.rxy(0.50, 0.45).wh(100, 20).anchor(0.5);
    textbox.rxy(0.5, 0.5).wh(60, 20).anchor(0.5);
    buttonok.rxy(0.50, 0.55).wh(60, 20).anchor(0.5);
    buttonok2.rxy(0.35, 0.55).wh(60, 20).anchor(0.5);
    buttonok3.rxy(0.65, 0.55).wh(60, 20).anchor(0.5);

    c.getSubject().openUI(ui);
}

function passwordtest(c) 
{
    var states = c.getServer().getStates();
    var uiContext = c.getSubject().getUIContext();
    var data = uiContext.getData();
    var pos = c.getSubject().getPosition();
    var zero = 0;
    var s = c.getSubject();

    if (uiContext.getLast() === "passwordstring") 
    {
        c.getWorld().playSound("minecraft:entity.pig.ambient", pos.x, pos.y, pos.z, 0.5, 2);
    }
    else if (uiContext.getLast() === "buttonok") 
    {
        var data = uiContext.getData();
        var passtates = c.getServer().getStates();

        if (data.getString("passwordstring") == passtates.getNumber("password")) 
        {
            s.setGameMode(2);
            c.getSubject().closeUI();
            c.executeCommand("/setblock -845 243 65 minecraft:grass");
        } 
        else 
        {
            var label = uiContext.get('labelpassword');
            label.label('[4Неверное [fвыражение');
        }
    }
    else if (uiContext.getLast() === "buttonclose") 
    {
        c.getSubject().closeUI();
        states.setNumber("on_off", 0);
    }
    else if (uiContext.getLast() === "buttonok2") 
    {
        c.getSubject().closeUI();
        states.setNumber("on_off", 1);
    }
}